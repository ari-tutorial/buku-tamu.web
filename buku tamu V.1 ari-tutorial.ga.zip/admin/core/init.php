<?php
require_once('db/connect.php');
require_once('function/data.php');
?>
