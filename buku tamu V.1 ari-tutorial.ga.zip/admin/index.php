<?php
@session_start();
if (@$_SESSION['admin']) {
require_once('core/init.php');
require_once('../dist/sidebar.php');

$result = tampilData();
$result = search();
?>
    <title>Dasbor Admin - Buku Tamu</title>

    <main>
      <div class="section right" style="margin-right: 10px;">
        <div class="col s12">
          <form action="" method="post">
            <input id="search-box" name="input_cari" size="40" type="text" placeholder="Masukkan Nama Lengkap"/>
            <input id="search-btn" name="cari_data" value="Cari Tamu" type="submit"/>
          </form>
        </div>
      </div>

      <div class="row">
        <form class="col s12">
          <table class="responsive-table">
            <thead>
              <tr>
                  <th>No. Tamu</th>
                  <th>Nama Lengkap</th>
                  <th>No. Telp</th>
                  <th>Alamat </th>
                  <th>Asal Sekolah</th>
                  <th>Opsi</th>
              </tr>
            </thead>

            <?php
              while($row = mysqli_fetch_assoc($result)):
            ?>
            
            <tbody>
              <tr>
                <td><?= $row['notamu']; ?></td>
                <td><?= $row['nama']; ?></td>
                <td><?= $row['notelp']; ?></td>
                <td><?= $row['alamat']; ?></td>
                <td><?= $row['sekolah']; ?></td>
                <td>
                 
                  <a href="delete_bukutamu.php?id=<?php echo $row['id']; ?>" style="color:red;" title="Hapus"><i class="material-icons">delete</i></a>
                </td>
              </tr>
            </tbody>
            <?php
          endwhile;
            ?>
          </table>
        </form>
      </div>
    </main>

<?php
}else {
  header("location:/index.php");
}
require_once('../dist/footer.php');
?>
