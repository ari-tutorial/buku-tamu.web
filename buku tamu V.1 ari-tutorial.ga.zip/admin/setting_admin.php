<?php
require_once('core/init.php');
require_once('../dist/sidebar.php');
?>

	<title>Setting Admin - Buku Tamu</title>

	<main>
    <div class="section row">
      <div class="col s7 push-s5">

			</div>
      <div class="col s5 pull-s7">
				<div class="row">
		      <div class="col s12 m8">
		        <div class="card-panel teal">
		          <span class="white-text">Sedang Diperbaiki</span>
		        </div>
		      </div>
		    </div>
			</div>
    </div>
	</main>

<?php
require_once('../dist/footer.php');
?>
