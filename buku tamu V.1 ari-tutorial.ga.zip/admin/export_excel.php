<?php
// Skrip berikut ini adalah skrip yang bertugas untuk meng-export data tadi ke excell
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=nama_filenya.xml");
?>

<h3>Data Tamu</h3>

<table border="1" cellpadding="5">
	<tr>
		<th>No. Tamu</th>
		<th>Nama Lengkap</th>
		<th>No. Telp</th>
		<th>Alamat</th>
		<th>Asal Sekolah</th>
	</tr>
	<?php
	// Load file koneksi.php
	include "db/connect.php";
	// Buat query untuk menampilkan semua data siswa
	$sql = $link->prepare("SELECT * FROM tb_buku");
	$sql->execute(); // Eksekusi querynya
	$no = 1; // Untuk penomoran tabel, di awal set dengan 1
	while($data = $sql->fetch()){ // Ambil semua data dari hasil eksekusi $sql
		echo "<tr>";
		echo "<td>".$no."</td>";
		echo "<td>".$data['notamu']."</td>";
		echo "<td>".$data['nama']."</td>";
		echo "<td>".$data['notelp']."</td>";
		echo "<td>".$data['alamat']."</td>";
		echo "<td>".$data['sekolah']."</td>";
		echo "</tr>";
		$no++; // Tambah 1 setiap kali looping
	}
	?>
</table>