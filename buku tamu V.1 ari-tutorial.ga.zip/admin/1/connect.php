<?php
$link = mysqli_connect("localhost", "root", "", "db_tamdesapp") or die(mysqli_error($link))
?>
