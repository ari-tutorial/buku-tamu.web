<h2> Student's Data <h2>
<?php
include 'connect.php';
$query = "SELECT * FROM tb_login"; //the query for get all data in tb_student
$result = mysql_query($query);

echo "<table border='0' cellpadding='2' cellspacing='2'>";
echo "<tr bgcolor='orange' align='center'>
		<td> <b> User </b> </td>
        <td> <b> Password </b> </td>

     </tr>";
while ($data = mysql_fetch_array($result)) //mysql_fetch_array = get the query data into array
{
  echo "<tr align='center'>
  			<td>".$data['username']."</td>
            <td>".$data['password']."</td>
            <td> <i> <a href='formupdate.php?no=".$data['no']."'> Update </a> </i></td>
       </tr>";
}
echo "</table>";
?>