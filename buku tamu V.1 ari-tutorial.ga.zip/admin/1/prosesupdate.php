<?php
include "connect.php";
//get the value from form update
 $no = $_POST['no'];
 $nausernameme = $_POST['username'];
 $password = $_POST['password'];

//query for update data in database
 $query = "UPDATE tb_student SET username = '$username', password = '$password' WHERE no = '$no'" ;
 $hasil = mysql_query($query);
 //see the result
 if ($hasil) {
    include "data.php";
	echo "<h4> update data success </h4>";
}
?>